# Lab 1. Arithmetic

"The book" referenced in the source code can be found [here](https://github.com/MPRI/M2-4-2/blob/master/Types%20and%20Programming%20Languages.pdf)

## TODO:

Replace TODO: comments in files:

- `src/semantics.py`
- `src/term.py` 

## How To Run Examples?

- `python main.py examples/01_pred.nb`
- `python main.py examples/02_ifelse.nb`
- `python main.py examples/03_stuck.nb`

