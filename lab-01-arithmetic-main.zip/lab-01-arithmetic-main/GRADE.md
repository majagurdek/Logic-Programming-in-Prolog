Dear Student,

I'm happy to announce that you've managed to get **4** out of 4 points for this assignment.\
Me and all the other virtual entities [salute you](https://tenor.com/xtvD.gif).

-----------
I remain your faithful servant\
_Bobot_